package com.acme.domain;

public interface Product {
    public abstract String getName();
    public abstract void setName(String n);

    public abstract String toString();
}
